<?php
session_start();
error_reporting(0);
require_once('include/config.php');
if(strlen( $_SESSION["uid"])==0)
    {   
header('location:login.php');
}
else{
// Code for change password 

 include 'include/db.php';
 if (isset($_POST["submit"])) {
        $feedback=($_POST['feedback']); 
        $email=($_POST['email']); 
       
        

        $query    = "INSERT into `feedback` (feedback,email)
        VALUES ('$feedback','$email')";
                     
        $result= mysqli_query($con, $query);
        
        if ($result) {
            echo "<script>alert('Feedback Saved');</script>";
            
            ?>
           <script>
            window.location.href='index.php';
           </script>
        <?php } else {
            echo "<script>alert('Feedback not Saved');</script>";
        }
    }
?>
 


<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Fashi Template">
    <title>DHMS | Change Password</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Muli:300,400,500,600,700,800,900&display=swap" rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/themify-icons.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
    <style>
        .border{
            background-color: #e3e3e3;
         
        }
        label{
            font-weight: bold;
        }
    </style>
</head>

<body>
   
   <!-- Header Section Begin -->
    <?php include 'include/header.php'; ?>
    <!-- Header End -->

  <div class="breacrumb-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-text">
                        <a href="#"><i class="fa fa-home"></i> Home</a>
                        <span>Change Password!</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="register-login-section spad">
        <div class="container">
            <div class="row border">
                <div class="col-lg-6 offset-lg-3">
                    <div class="login-form">
                        <h2 >Feedback</h2>
                        <hr>
                        <?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
                else if($msg){?><div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div><?php }?>

                        <form method="post" name="chngpwd" onSubmit="return valid();">
                        <div class="form-group">
                <label for="comment"> <span style="font-size: 23px;color:#37517e;">Massage</span> </label>
                <textarea class="form-control" rows="8" id="comment" name="feedback" required ></textarea>
              </div>
              <div class="mail-service" style="color:white;">
                    <?php if(strlen($_SESSION['uid'])!=0): ?>
                       
                           
                            
                            <input type="hidden" value=" <?php echo $_SESSION['email'];?>" name="email">
                            <?php endif;?>
                    </div>
                           
                             <input type="submit" name="submit" id="submit" value="Save Feedback" class="site-btn login-btn"> 
                             <br><br><br>
                        </form>
           
                        
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer Section Begin -->
    <?php include 'include/footer.php'; ?>
    <!-- Footer Section End -->

    <!-- Js Plugins -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.countdown.min.js"></script>
    <script src="js/jquery.zoom.min.js"></script>
    <script src="js/jquery.dd.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>
</body>

</html>

   <?php } ?>


<script type="text/javascript">
function valid()
{
if(document.chngpwd.newpassword.value!= document.chngpwd.confirmpassword.value)
{
alert("New Password and Confirm Password Field do not match  !!");
document.chngpwd.confirmpassword.focus();
return false;
}
return true;
}
</script>
  <style>
.errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #dd3d36;
    color:#fff;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
    background: #5cb85c;
    color:#fff;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
        </style>