<?php
 include 'include/db.php';
 if (isset($_POST["submit"])) {
        $fullname=($_POST['fullname']); 
        $email=($_POST['email']); 
        $subject=($_POST['subject']); 
        $Massage=($_POST['Massage']); 
        

        $query    = "INSERT into `contact` (fullname,email,subject,Massage)
        VALUES ('$fullname','$email','$subject','$Massage')";
                     
        $result= mysqli_query($con, $query);
        
        if ($result) {
            echo "<script>alert('Massage has been send');</script>";
            
            ?>
           <script>
            window.location.href='index.php';
           </script>
        <?php } else {
            echo "<script>alert('Massage has been not send');</script>";
        }
    }
?>
 