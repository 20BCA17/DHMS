
<header class="header-section">
        <div class="header-top">
            
            <div class="container">
                <div class="ht-left" style="float: right;">
                    <div class="mail-service" style="color:white;">
                    <?php if(strlen($_SESSION['uid'])!=0): ?>
                        <i class=" fa fa-envelope"></i>
                            <?php echo $_SESSION['email'];?>
                            <?php endif;?>
                    </div>
                    <div class="phone-service" style="color:white;">
                      <?php if(strlen($_SESSION['uid'])!=0): ?>
                            <i class=" fa fa-user"></i>
                           <?php echo $_SESSION['name'];?>
                        <?php endif;?>  
                    </div>
                </div>
                <div class="ht-right">
                    <?php if(strlen($_SESSION['uid'])==0): ?>
                    <a href="login.php" class="login-panel text" style="color:white;"> <i class="fa fa-user"></i> <strong> User Login</strong></a>
                    <?php else :?>
                        
                       
                    
                    <?php endif;?>
               
                </div>
            </div>
        </div>
        <div class="container">
            <div class="inner-header">
                <div class="row">
                    <div class="col-lg-5 col-md-2">
                        <div class="logo">
                            <a href="index.php">
                          <h3>  DHMS </h3>
                          <small>Driver Hiring Management System</small>
                            </a>
                        </div>
                    </div>
                    <!-- <div class="col-lg-9 col-md-9">
                        <div class="advanced-search">
                            
                            <div class="input-group">
                                <input type="text" name="search" id="search" placeholder="What do you need?">
                                <button type="button"><i class="ti-search"></i></button>
                            </div>
                        </div>
                    </div> -->
                   
                </div>
            </div>
        </div>
        <style>
.dropbtn {
  background-color: #37517e;
  color: white;
  padding: 16px;
  font-size: 16px;
  border: none;
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #ddd;}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {background-color: #6781ae;}
</style>
        <div class="nav-item">
            <div class="container">
               
                <nav class="nav-menu mobile-menu">
                    <ul>
                        <?php if(strlen($_SESSION['uid'])==0): ?>
                            
                        <li class="active"><a href="index.php">Home</a></li>
                       <li><a href="drivers/login.php">Driver Login</a></li>
                       <li><a href="admin/login.php">Admin Login</a></li>
                       <?php else :?>
                        <li class="active"><a href="index.php">Home</a></li>
                         <li><a href="profile.php">My Profile</a></li>
                          <li><a href="change-password.php">Change Password</a></li>
                            <li><a href="booking-history.php">Book History</a></li>
                           <li><a href="feedback.php">Feedback</a></li>
                           <div class="dropdown">
  <button class="dropbtn"> <strong>Action</strong> </button>
  <div class="dropdown-content">
     <a href="profile.php" class="login-panel"><i class="fa fa-gear"></i>&nbsp;&nbsp;Profiles </a>
     <a href="change-password.php" class="login-panel"><i class="fa fa-lock"></i>&nbsp;&nbsp;Setting &nbsp;</a>
     <a href="logout.php"><i class="fa fa-sign-out"></i>&nbsp;&nbsp;Logout</a>
  </div>
</div>
                        
                        </li>
                           
                          
                           
                       <?php endif;?>
                    </ul>
                </nav>
                <div id="mobile-menu-wrap"></div>
            </div>
        </div>
    </header>